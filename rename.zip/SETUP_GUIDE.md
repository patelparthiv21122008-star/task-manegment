# TaskFlow - Task Management Application
## Complete Setup & Implementation Guide

---

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Prerequisites](#prerequisites)
4. [Installation & Setup](#installation--setup)
5. [Database Schema](#database-schema)
6. [API Documentation](#api-documentation)
7. [Frontend Setup](#frontend-setup)
8. [Running the Application](#running-the-application)
9. [Authentication Flow](#authentication-flow)
10. [Features & Usage](#features--usage)
11. [Deployment Guide](#deployment-guide)
12. [Troubleshooting](#troubleshooting)

---

## 🎯 Project Overview

**TaskFlow** is a full-stack task management web application that helps users organize, track, and manage their tasks efficiently. Built with modern web technologies, it provides real-time updates, responsive design, and secure authentication.

### Key Features
- ✅ User authentication with JWT
- ✅ Full CRUD operations for tasks
- ✅ Task filtering by status and priority
- ✅ Search functionality
- ✅ Real-time updates (optimized for responsive design)
- ✅ Mobile-friendly responsive design
- ✅ Task priority levels (Low, Medium, High)
- ✅ Task status tracking (To Do, In Progress, Done)
- ✅ Professional, clean UI with animations

---

## 🏗️ Architecture

### Technology Stack

**Frontend:**
- React 18+
- CSS3 (with CSS variables and animations)
- Vite (build tool)
- Fetch API (for HTTP requests)

**Backend:**
- Node.js & Express.js
- JWT (JSON Web Tokens) for authentication
- bcrypt for password hashing
- Sequelize ORM (for database abstraction)
- PostgreSQL (recommended for production)

**Database:**
- PostgreSQL (production)
- In-memory storage (development/demo)

### File Structure
```
taskflow/
├── frontend/
│   ├── TaskApp.jsx          # Main React component
│   ├── TaskApp.css          # Styling
│   └── vite.config.js       # Vite configuration
├── backend/
│   ├── server.js            # Express server & API routes
│   ├── package.json         # Dependencies
│   └── .env                 # Environment variables
├── database/
│   └── schema.sql           # PostgreSQL schema
└── README.md

```

---

## 📋 Prerequisites

Before starting, ensure you have:

- **Node.js** (v16+) - [Download](https://nodejs.org/)
- **npm** (v7+) or **yarn**
- **PostgreSQL** (v12+) - [Download](https://www.postgresql.org/download/)
- **Git**
- A code editor (VS Code recommended)

### Verify Installation
```bash
# Check Node.js
node --version

# Check npm
npm --version

# Check PostgreSQL
psql --version
```

---

## 🚀 Installation & Setup

### 1. Clone/Create Project Directory
```bash
mkdir taskflow
cd taskflow
```

### 2. Backend Setup

#### 2a. Create Backend Directory
```bash
mkdir backend
cd backend
```

#### 2b. Initialize npm and Install Dependencies
```bash
npm init -y
npm install express cors jsonwebtoken bcrypt dotenv pg sequelize
npm install --save-dev nodemon
```

#### 2c. Create Environment File
```bash
cp .env.example .env
```

Edit `.env` file with your configuration:
```env
PORT=5000
NODE_ENV=development
JWT_SECRET=your-secure-random-secret-key-here
DB_HOST=localhost
DB_PORT=5432
DB_NAME=taskflow_db
DB_USER=postgres
DB_PASSWORD=your_password
CORS_ORIGIN=http://localhost:3000,http://localhost:5173
```

#### 2d. Copy Backend Files
- Copy `server.js` to the `backend/` directory

### 3. Frontend Setup

#### 3a. Create React App with Vite
```bash
cd ..
npm create vite@latest frontend -- --template react
cd frontend
npm install
```

#### 3b. Copy Frontend Files
- Copy `TaskApp.jsx` to `frontend/src/`
- Copy `TaskApp.css` to `frontend/src/`

#### 3c. Update Frontend Entry Point
Edit `frontend/src/main.jsx`:
```jsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import TaskApp from './TaskApp'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TaskApp />
  </React.StrictMode>,
)
```

Edit `frontend/vite.config.js`:
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
  }
})
```

### 4. Database Setup

#### 4a. Create PostgreSQL Database
```bash
# Connect to PostgreSQL
psql -U postgres

# Create database (in psql console)
CREATE DATABASE taskflow_db;

# Connect to the database
\c taskflow_db

# Paste the schema from below (see Database Schema section)
```

#### 4b. Alternative: Using Database GUI
- Use **pgAdmin** or **DBeaver** to create database visually
- Create database named `taskflow_db`
- Run SQL schema script

---

## 📊 Database Schema

Run this SQL in your PostgreSQL database:

```sql
-- Create Users Table
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Tasks Table
CREATE TABLE tasks (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  priority VARCHAR(50) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  status VARCHAR(50) DEFAULT 'todo' CHECK (status IN ('todo', 'in-progress', 'done')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Indexes for Performance
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_users_email ON users(email);
```

### Database Diagram

```
Users
├── id (PK)
├── email (UNIQUE)
├── name
├── password (hashed)
├── created_at
└── updated_at
     ↓
Tasks (1:N relationship)
├── id (PK)
├── user_id (FK)
├── title
├── description
├── priority (low|medium|high)
├── status (todo|in-progress|done)
├── created_at
└── updated_at
```

---

## 🔌 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication
All task endpoints require JWT token in Authorization header:
```
Authorization: Bearer <token>
```

### Endpoints

#### 1. User Registration
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securePassword123",
  "name": "John Doe"
}
```

**Response (201):**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe"
  }
}
```

---

#### 2. User Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securePassword123"
}
```

**Response (200):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe"
  }
}
```

---

#### 3. Get All Tasks
```http
GET /api/tasks
Authorization: Bearer <token>
```

**Response (200):**
```json
[
  {
    "id": 1,
    "userId": 1,
    "title": "Complete project proposal",
    "description": "Finish and submit the Q1 project proposal",
    "priority": "high",
    "status": "in-progress",
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-16T14:20:00Z"
  }
]
```

---

#### 4. Create Task
```http
POST /api/tasks
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Fix login bug",
  "description": "Users unable to reset password",
  "priority": "high",
  "status": "todo"
}
```

**Response (201):**
```json
{
  "id": 2,
  "userId": 1,
  "title": "Fix login bug",
  "description": "Users unable to reset password",
  "priority": "high",
  "status": "todo",
  "createdAt": "2024-01-16T15:45:00Z",
  "updatedAt": "2024-01-16T15:45:00Z"
}
```

---

#### 5. Update Task
```http
PUT /api/tasks/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Updated title",
  "status": "in-progress",
  "priority": "medium"
}
```

**Response (200):** Updated task object

---

#### 6. Delete Task
```http
DELETE /api/tasks/:id
Authorization: Bearer <token>
```

**Response (200):**
```json
{
  "message": "Task deleted successfully",
  "task": { /* task object */ }
}
```

---

#### 7. Health Check
```http
GET /api/health
```

**Response (200):**
```json
{
  "status": "Server is running"
}
```

---

## 🎨 Frontend Setup

### Using Vite + React

#### Install Dependencies
```bash
cd frontend
npm install
npm install axios  # Optional: for HTTP requests (using fetch instead)
```

#### Environment Configuration
Create `frontend/.env`:
```env
VITE_API_URL=http://localhost:5000/api
```

#### Project Structure
```
frontend/
├── src/
│   ├── main.jsx          # Entry point
│   ├── TaskApp.jsx       # Main component
│   ├── TaskApp.css       # Styles
│   └── index.html        # HTML template
├── vite.config.js
├── package.json
└── .env
```

---

## ▶️ Running the Application

### Terminal 1: Start Backend
```bash
cd backend
npm start
# or for development with auto-reload
npm run dev
```

You should see:
```
✓ Server running on http://localhost:5000
✓ API base URL: http://localhost:5000/api
```

### Terminal 2: Start Frontend
```bash
cd frontend
npm run dev
```

You should see:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  press h to show help
```

### Terminal 3: Access Application
Open browser and navigate to:
```
http://localhost:5173
```

---

## 🔐 Authentication Flow

### Registration Flow
```
1. User fills registration form
   ↓
2. Frontend POST /auth/register with credentials
   ↓
3. Backend validates input and checks for existing email
   ↓
4. Password is hashed using bcrypt
   ↓
5. User record created in database
   ↓
6. JWT token generated and returned
   ↓
7. Token stored in localStorage (client-side)
   ↓
8. User redirected to dashboard
```

### Login Flow
```
1. User enters email and password
   ↓
2. Frontend POST /auth/login
   ↓
3. Backend finds user by email
   ↓
4. Password verified against hashed password
   ↓
5. JWT token generated if credentials valid
   ↓
6. Token stored in localStorage and state
   ↓
7. API calls include token in Authorization header
```

### Token Structure
```
Header: { "alg": "HS256", "typ": "JWT" }
Payload: { "userId": 1, "iat": ..., "exp": ... }
Signature: HMAC-SHA256(header.payload, secret)
```

---

## 💡 Features & Usage

### Task Creation
1. Click "New Task" button
2. Enter task title (required)
3. Add description (optional)
4. Select priority (Low, Medium, High)
5. Click "Create Task"

### Task Management
- **Update**: Click edit icon, modify fields, click Save
- **Change Status**: Use dropdown menu (To Do → In Progress → Done)
- **Delete**: Click trash icon (confirmable)
- **Search**: Use search box to filter by title/description
- **Filter**: Click status filter tabs (All, To Do, In Progress, Done)

### Task Priorities
- 🔴 **High**: Urgent, important tasks
- 🟡 **Medium**: Standard priority tasks
- 🟢 **Low**: Non-urgent tasks

### Task Statuses
- **To Do**: Not started
- **In Progress**: Currently working on
- **Done**: Completed

### Dashboard Stats
- **Total Tasks**: All tasks for user
- **In Progress**: Tasks being worked on
- **Completed**: Finished tasks

---

## 🚀 Deployment Guide

### Backend Deployment (Heroku)

#### 1. Install Heroku CLI
```bash
# macOS
brew tap heroku/brew && brew install heroku

# Windows/Other
# Download from https://devcenter.heroku.com/articles/heroku-cli
```

#### 2. Login and Create App
```bash
heroku login
heroku create your-app-name
```

#### 3. Set Environment Variables
```bash
heroku config:set JWT_SECRET=your-production-secret
heroku config:set DATABASE_URL=your-postgres-url
```

#### 4. Deploy
```bash
git push heroku main
```

### Frontend Deployment (Vercel)

#### 1. Install Vercel CLI
```bash
npm install -g vercel
```

#### 2. Deploy
```bash
cd frontend
vercel
```

#### 3. Configure Environment
Update `vercel.json` for API URL:
```json
{
  "env": {
    "VITE_API_URL": "@api-url"
  }
}
```

### Database Deployment

**Recommended Cloud Databases:**
- AWS RDS PostgreSQL
- Heroku Postgres
- Azure Database for PostgreSQL
- Google Cloud SQL

Update connection string in `.env`:
```env
DATABASE_URL=postgresql://user:password@host:port/dbname
```

---

## 🐛 Troubleshooting

### Common Issues & Solutions

#### 1. "Cannot GET /api/tasks"
**Problem:** Backend not running or wrong API URL
**Solution:**
```bash
# Check if backend is running
curl http://localhost:5000/api/health

# Verify API_URL in frontend .env
# Should be http://localhost:5000/api
```

#### 2. "CORS Error"
**Problem:** Frontend and backend on different ports
**Solution:** Update CORS in `server.js`:
```javascript
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:5173']
}));
```

#### 3. "Invalid Token" or "401 Unauthorized"
**Problem:** Token expired or not sent correctly
**Solution:**
- Clear localStorage: `localStorage.clear()`
- Login again to get new token
- Check Authorization header format: `Bearer <token>`

#### 4. "Password hash mismatch on login"
**Problem:** bcrypt version mismatch
**Solution:**
```bash
npm install bcrypt@5.1.1
npm rebuild bcrypt
```

#### 5. "Database connection failed"
**Problem:** PostgreSQL not running or wrong credentials
**Solution:**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Verify connection
psql -U postgres -h localhost

# Check .env credentials
# Default: user=postgres, password=postgres
```

#### 6. Port Already in Use
**Problem:** Another process using port 5000 or 3000
**Solution:**
```bash
# Kill process on port 5000 (macOS/Linux)
lsof -ti:5000 | xargs kill -9

# Or use different port in .env
PORT=5001
```

---

## 📚 Learning Outcomes

After completing this project, you'll understand:

### Frontend
- ✅ React component lifecycle and hooks
- ✅ State management and prop drilling
- ✅ Form handling and validation
- ✅ API integration with fetch
- ✅ Authentication token management
- ✅ Responsive CSS design
- ✅ UI/UX best practices

### Backend
- ✅ Express.js server setup
- ✅ RESTful API design principles
- ✅ JWT authentication & authorization
- ✅ Password hashing with bcrypt
- ✅ Request validation
- ✅ Error handling & HTTP status codes
- ✅ CORS configuration

### Database
- ✅ SQL schema design
- ✅ Relationships and constraints
- ✅ Database indexing for performance
- ✅ Data integrity with foreign keys

### DevOps
- ✅ Environment configuration
- ✅ Local development setup
- ✅ Cloud deployment
- ✅ Database migration strategies

---

## 🎓 Next Steps & Enhancements

### Phase 2 Features
1. **WebSocket Integration**: Real-time updates without polling
2. **Task Categories**: Organize tasks into projects
3. **Collaboration**: Share tasks and invite team members
4. **Notifications**: Email/push notifications for task updates
5. **Recurring Tasks**: Automated task creation
6. **Task Analytics**: Charts and progress tracking
7. **File Attachments**: Attach files to tasks
8. **Comments**: Collaborate within tasks
9. **Dark Mode**: Theme switching
10. **Mobile App**: Native iOS/Android app

### Code Improvements
- Add comprehensive test suite (Jest, React Testing Library)
- Implement error boundaries in React
- Add loading skeletons and progressive enhancement
- Create reusable hooks for API calls
- Add request caching and offline support
- Implement activity logging
- Add role-based access control (RBAC)
- Database migrations with Sequelize

---

## 📞 Support & Resources

### Documentation
- [Express.js Docs](https://expressjs.com/)
- [React Docs](https://react.dev/)
- [PostgreSQL Docs](https://www.postgresql.org/docs/)
- [JWT.io](https://jwt.io/)

### Tools
- [Postman](https://www.postman.com/) - API testing
- [pgAdmin](https://www.pgadmin.org/) - Database management
- [VS Code](https://code.visualstudio.com/) - Code editor

---

## 📄 License

This project is provided as-is for educational purposes.

---

**Happy coding! 🚀**
