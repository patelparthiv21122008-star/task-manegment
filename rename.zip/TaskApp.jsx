import React, { useState, useEffect, useCallback } from 'react';
import './TaskApp.css';

// ==================== COMPONENTS ====================

const AuthScreen = ({ onLogin, isLoading }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({ email: '', password: '', name: '' });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (!formData.email || !formData.password || (isSignUp && !formData.name)) {
      setError('All fields are required');
      return;
    }

    try {
      await onLogin(formData, isSignUp);
    } catch (err) {
      setError(err.message || 'Authentication failed');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <h1>TaskFlow</h1>
          <p>Organize your work, amplify your focus</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {isSignUp && (
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button 
            type="submit" 
            className="btn-primary" 
            disabled={isLoading}
          >
            {isLoading ? 'Loading...' : (isSignUp ? 'Create Account' : 'Sign In')}
          </button>
        </form>

        <div className="auth-toggle">
          <p>
            {isSignUp ? 'Already have an account?' : "Don't have an account?"}
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError('');
                setFormData({ email: '', password: '', name: '' });
              }}
              className="toggle-btn"
            >
              {isSignUp ? 'Sign In' : 'Sign Up'}
            </button>
          </p>
        </div>
      </div>

      <div className="auth-backdrop"></div>
    </div>
  );
};

const TaskItem = ({ task, onUpdate, onDelete, isEditing, onEditToggle }) => {
  const [editedTask, setEditedTask] = useState(task);

  const handleSave = () => {
    onUpdate(task.id, editedTask);
    onEditToggle();
  };

  const handlePriorityChange = (priority) => {
    onUpdate(task.id, { ...task, priority });
  };

  return (
    <div className={`task-item task-${task.priority}`} data-status={task.status}>
      {isEditing ? (
        <div className="task-edit-mode">
          <input
            type="text"
            value={editedTask.title}
            onChange={(e) => setEditedTask({ ...editedTask, title: e.target.value })}
            className="task-edit-input"
            placeholder="Task title..."
          />
          <textarea
            value={editedTask.description}
            onChange={(e) => setEditedTask({ ...editedTask, description: e.target.value })}
            className="task-edit-textarea"
            placeholder="Task description..."
          />
          <div className="edit-actions">
            <button onClick={handleSave} className="btn-save">Save</button>
            <button onClick={onEditToggle} className="btn-cancel">Cancel</button>
          </div>
        </div>
      ) : (
        <>
          <div className="task-content">
            <div className="task-header">
              <h3 className="task-title">{task.title}</h3>
              <div className="task-meta">
                <span className={`priority-badge priority-${task.priority}`}>
                  {task.priority}
                </span>
                <span className={`status-badge status-${task.status}`}>
                  {task.status}
                </span>
              </div>
            </div>
            {task.description && <p className="task-description">{task.description}</p>}
            <div className="task-footer">
              <span className="task-date">{new Date(task.createdAt).toLocaleDateString()}</span>
            </div>
          </div>

          <div className="task-actions">
            <select
              value={task.status}
              onChange={(e) => onUpdate(task.id, { ...task, status: e.target.value })}
              className="status-select"
            >
              <option value="todo">To Do</option>
              <option value="in-progress">In Progress</option>
              <option value="done">Done</option>
            </select>
            <button onClick={onEditToggle} className="btn-icon" title="Edit">✏️</button>
            <button onClick={() => onDelete(task.id)} className="btn-icon btn-delete" title="Delete">🗑️</button>
          </div>
        </>
      )}
    </div>
  );
};

const TaskDashboard = ({ user, tasks, onAddTask, onUpdateTask, onDeleteTask, onLogout }) => {
  const [showForm, setShowForm] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', description: '', priority: 'medium' });
  const [filter, setFilter] = useState('all');
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddTask = async (e) => {
    e.preventDefault();
    if (!newTask.title.trim()) return;

    try {
      await onAddTask(newTask);
      setNewTask({ title: '', description: '', priority: 'medium' });
      setShowForm(false);
    } catch (err) {
      console.error('Failed to add task:', err);
    }
  };

  const filteredTasks = tasks.filter(task => {
    const matchesFilter = filter === 'all' || task.status === filter;
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === 'done').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <h1>TaskFlow</h1>
          <p className="user-greeting">Welcome, <strong>{user.name}</strong></p>
        </div>
        <button onClick={onLogout} className="btn-logout">Sign Out</button>
      </header>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-number">{stats.total}</div>
          <div className="stat-label">Total Tasks</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{stats.inProgress}</div>
          <div className="stat-label">In Progress</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{stats.completed}</div>
          <div className="stat-label">Completed</div>
        </div>
      </div>

      <div className="dashboard-controls">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="filter-tabs">
          {['all', 'todo', 'in-progress', 'done'].map(status => (
            <button
              key={status}
              className={`filter-tab ${filter === status ? 'active' : ''}`}
              onClick={() => setFilter(status)}
            >
              {status === 'all' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-add-task"
        >
          + New Task
        </button>
      </div>

      {showForm && (
        <div className="add-task-form">
          <form onSubmit={handleAddTask}>
            <div className="form-group">
              <input
                type="text"
                placeholder="Task title..."
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                className="form-input"
                autoFocus
              />
            </div>
            <div className="form-group">
              <textarea
                placeholder="Task description (optional)"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                className="form-textarea"
                rows="3"
              />
            </div>
            <div className="form-row">
              <select
                value={newTask.priority}
                onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
                className="form-select"
              >
                <option value="low">Low Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="high">High Priority</option>
              </select>
              <div className="form-actions">
                <button type="submit" className="btn-primary">Create Task</button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setNewTask({ title: '', description: '', priority: 'medium' });
                  }}
                  className="btn-secondary"
                >
                  Cancel
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      <div className="tasks-container">
        {filteredTasks.length === 0 ? (
          <div className="empty-state">
            <p>No tasks yet. Create one to get started!</p>
          </div>
        ) : (
          <div className="tasks-list">
            {filteredTasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onUpdate={onUpdateTask}
                onDelete={onDeleteTask}
                isEditing={editingId === task.id}
                onEditToggle={() => setEditingId(editingId === task.id ? null : task.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ==================== MAIN APP ====================

export default function TaskApp() {
  const [authState, setAuthState] = useState({
    isAuthenticated: false,
    user: null,
    token: null,
  });

  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

  // Initialize from localStorage
  useEffect(() => {
    const savedAuth = localStorage.getItem('taskapp_auth');
    if (savedAuth) {
      const auth = JSON.parse(savedAuth);
      setAuthState(auth);
      if (auth.token) {
        fetchTasks(auth.token);
      }
    }
  }, []);

  const handleAuth = async (credentials, isSignUp) => {
    setIsLoading(true);
    try {
      const endpoint = isSignUp ? '/auth/register' : '/auth/login';
      const response = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Authentication failed');
      }

      const data = await response.json();
      const newAuthState = {
        isAuthenticated: true,
        user: data.user,
        token: data.token,
      };

      setAuthState(newAuthState);
      localStorage.setItem('taskapp_auth', JSON.stringify(newAuthState));
      
      await fetchTasks(data.token);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchTasks = async (token) => {
    setIsSyncing(true);
    try {
      const response = await fetch(`${API_BASE}/tasks`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setTasks(data);
      }
    } catch (err) {
      console.error('Failed to fetch tasks:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAddTask = async (taskData) => {
    try {
      const response = await fetch(`${API_BASE}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authState.token}`,
        },
        body: JSON.stringify(taskData),
      });

      if (response.ok) {
        const newTask = await response.json();
        setTasks([...tasks, newTask]);
      }
    } catch (err) {
      console.error('Failed to add task:', err);
      throw err;
    }
  };

  const handleUpdateTask = async (taskId, updates) => {
    try {
      const response = await fetch(`${API_BASE}/tasks/${taskId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authState.token}`,
        },
        body: JSON.stringify(updates),
      });

      if (response.ok) {
        const updatedTask = await response.json();
        setTasks(tasks.map(t => t.id === taskId ? updatedTask : t));
      }
    } catch (err) {
      console.error('Failed to update task:', err);
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      const response = await fetch(`${API_BASE}/tasks/${taskId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${authState.token}` },
      });

      if (response.ok) {
        setTasks(tasks.filter(t => t.id !== taskId));
      }
    } catch (err) {
      console.error('Failed to delete task:', err);
    }
  };

  const handleLogout = () => {
    setAuthState({
      isAuthenticated: false,
      user: null,
      token: null,
    });
    setTasks([]);
    localStorage.removeItem('taskapp_auth');
  };

  return (
    <>
      {!authState.isAuthenticated ? (
        <AuthScreen onLogin={handleAuth} isLoading={isLoading} />
      ) : (
        <TaskDashboard
          user={authState.user}
          tasks={tasks}
          onAddTask={handleAddTask}
          onUpdateTask={handleUpdateTask}
          onDeleteTask={handleDeleteTask}
          onLogout={handleLogout}
        />
      )}
    </>
  );
}
