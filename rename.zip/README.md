# TaskFlow 📋 - Task Management Application

A modern, full-stack task management web application built with React, Node.js/Express, and PostgreSQL. Features user authentication, real-time task management, responsive design, and a refined minimalist UI.

![TaskFlow Demo](https://img.shields.io/badge/version-1.0.0-blue)
![React](https://img.shields.io/badge/React-18%2B-61dafb?logo=react)
![Node.js](https://img.shields.io/badge/Node.js-16%2B-339933?logo=node.js)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-12%2B-336791?logo=postgresql)

---

## ✨ Key Features

### 🔐 Security & Authentication
- User registration and login with JWT authentication
- Secure password hashing with bcrypt
- Token-based authorization for all API endpoints
- Session persistence with localStorage

### 📝 Task Management
- **Create, Read, Update, Delete (CRUD)** operations
- Task prioritization (Low, Medium, High)
- Status tracking (To Do, In Progress, Done)
- Task descriptions and timestamps
- Automatic user association

### 🔍 Smart Task Organization
- Real-time search functionality
- Filter by status and priority
- View statistics (total, in-progress, completed)
- Dashboard with task counts

### 🎨 Modern UI/UX
- **Refined minimalist design** with professional aesthetics
- **Fully responsive** - works on desktop, tablet, and mobile
- Smooth animations and transitions
- Intuitive task interactions
- Clean typography and color scheme

### ⚡ Performance
- Optimized API calls with error handling
- Efficient state management
- CSS variables for theming
- Mobile-first responsive design

---

## 🏗️ Architecture

### Frontend
- **Framework**: React 18+ with Hooks
- **Build Tool**: Vite
- **Styling**: CSS3 with CSS Variables
- **API Client**: Fetch API
- **State Management**: React Hooks (useState, useEffect, useCallback)

### Backend
- **Runtime**: Node.js
- **Framework**: Express.js
- **Authentication**: JWT (jsonwebtoken)
- **Password Security**: bcrypt
- **Database ORM**: Sequelize
- **Database**: PostgreSQL (production)

### Database
- **PostgreSQL** for production
- Relational schema with users and tasks
- Indexes for performance optimization
- Foreign key relationships

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v16+
- **npm** v7+
- **PostgreSQL** v12+
- **Git**

### 1. Clone Repository
```bash
git clone <repository-url>
cd taskflow
```

### 2. Backend Setup
```bash
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Configure .env with your settings
# - JWT_SECRET: Use a strong random string
# - DB credentials: PostgreSQL connection details
nano .env

# Start server
npm run dev
# Server runs on http://localhost:5000
```

### 3. Database Setup
```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE taskflow_db;

# Run schema (copy schema from SETUP_GUIDE.md)
\c taskflow_db
-- Paste SQL schema here
```

### 4. Frontend Setup
```bash
cd frontend

# Install dependencies
npm install

# Create .env file
echo "VITE_API_URL=http://localhost:5000/api" > .env

# Start development server
npm run dev
# App opens at http://localhost:3000
```

### 5. Open Application
Visit: **http://localhost:3000**

---

## 📚 Documentation

### Complete Setup Guide
Detailed instructions available in **[SETUP_GUIDE.md](./SETUP_GUIDE.md)**

Includes:
- Full architecture overview
- Step-by-step installation
- Database schema with diagrams
- Complete API documentation
- Authentication flow
- Deployment guide
- Troubleshooting

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| GET | `/api/tasks` | Get all tasks (requires auth) |
| POST | `/api/tasks` | Create new task (requires auth) |
| GET | `/api/tasks/:id` | Get task by ID (requires auth) |
| PUT | `/api/tasks/:id` | Update task (requires auth) |
| DELETE | `/api/tasks/:id` | Delete task (requires auth) |

Full API documentation with examples: **[SETUP_GUIDE.md → API Documentation](./SETUP_GUIDE.md#-api-documentation)**

---

## 📂 Project Structure

```
taskflow/
├── frontend/
│   ├── src/
│   │   ├── TaskApp.jsx         # Main React component
│   │   ├── TaskApp.css         # Complete styling
│   │   └── main.jsx            # Entry point
│   ├── index.html              # HTML template
│   ├── vite.config.js          # Vite configuration
│   ├── package.json            # Frontend dependencies
│   └── .env                    # Environment config
│
├── backend/
│   ├── server.js               # Express server & API routes
│   ├── package.json            # Backend dependencies
│   ├── .env                    # Environment config
│   └── .env.example            # Environment template
│
├── SETUP_GUIDE.md              # Complete setup guide
└── README.md                   # This file
```

---

## 🔑 Key Components

### Frontend Components

**AuthScreen**
- User registration and login
- Form validation
- Error handling

**TaskDashboard**
- Task list management
- Statistics display
- Filter and search

**TaskItem**
- Task display and editing
- Status and priority management
- Edit/delete actions

### Backend Endpoints

**Authentication**
- `POST /api/auth/register` - New user signup
- `POST /api/auth/login` - User login

**Task Management**
- Full CRUD operations
- User-specific task filtering
- Status and priority management

---

## 🎯 Learning Outcomes

This project teaches:

### Frontend Development
✅ React fundamentals and hooks  
✅ Component composition and state management  
✅ API integration and async operations  
✅ Form handling and validation  
✅ Responsive design techniques  
✅ CSS animations and transitions  
✅ Authentication handling  

### Backend Development
✅ Express.js server setup  
✅ RESTful API design  
✅ JWT authentication  
✅ Password hashing and security  
✅ Request validation  
✅ Error handling  

### Database Design
✅ SQL schema design  
✅ Relationships and constraints  
✅ Indexing strategies  
✅ Data integrity  

### DevOps & Deployment
✅ Environment configuration  
✅ Local development workflow  
✅ Cloud deployment  
✅ Database migrations  

---

## 🔐 Security Features

- ✅ Passwords hashed with bcrypt (10 rounds)
- ✅ JWT tokens with expiration (7 days)
- ✅ CORS configured for frontend origin
- ✅ User authorization on all protected routes
- ✅ Input validation and sanitization
- ✅ HTTP-only cookie support (recommended for production)

---

## 📱 Responsive Design

### Breakpoints
- **Mobile**: < 480px (phones)
- **Tablet**: 480px - 768px (tablets)
- **Desktop**: > 768px (laptops, desktops)

### Features
- Mobile-first CSS approach
- Flexible grid layouts
- Touch-friendly controls
- Optimized typography sizes
- Adaptive navigation

---

## 🛠️ Development Commands

### Backend
```bash
cd backend

npm start          # Run production server
npm run dev        # Run with auto-reload (nodemon)
npm test           # Run tests
```

### Frontend
```bash
cd frontend

npm run dev        # Start development server
npm run build      # Build for production
npm run preview    # Preview production build
npm run lint       # Check code quality
```

---

## 🌐 Environment Variables

### Backend (.env)
```env
PORT=5000
NODE_ENV=development
JWT_SECRET=your-secret-key
DB_HOST=localhost
DB_PORT=5432
DB_NAME=taskflow_db
DB_USER=postgres
DB_PASSWORD=your_password
CORS_ORIGIN=http://localhost:3000,http://localhost:5173
```

### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
```

---

## 🚀 Deployment

### Frontend Deployment (Vercel)
```bash
cd frontend
vercel deploy
```

### Backend Deployment (Heroku)
```bash
heroku create your-app-name
git push heroku main
```

See **[SETUP_GUIDE.md → Deployment Guide](./SETUP_GUIDE.md#-deployment-guide)** for detailed instructions.

---

## 🐛 Troubleshooting

### Common Issues

**"Cannot GET /api/tasks"**
- Ensure backend is running on port 5000
- Check VITE_API_URL in frontend .env

**"CORS Error"**
- Verify CORS_ORIGIN in backend .env
- Includes your frontend URL

**"Login fails with 401"**
- Clear browser localStorage
- Try registering a new account
- Check database connection

**"Port already in use"**
- Change port in .env
- Or kill existing process: `lsof -ti:5000 | xargs kill -9`

See **[SETUP_GUIDE.md → Troubleshooting](./SETUP_GUIDE.md#-troubleshooting)** for more solutions.

---

## 📈 Performance Optimization

- Lazy loading of components
- Memoized callbacks and components
- CSS variable caching
- API request optimization
- Database indexes on frequently queried columns

---

## 🤝 Contributing

Contributions welcome! Areas for enhancement:
- WebSocket real-time updates
- Task categories/projects
- Collaboration features
- Dark mode
- Mobile app version
- Advanced analytics

---

## 📄 License

This project is provided for educational purposes.

---

## 📞 Support

For issues or questions:
1. Check **[SETUP_GUIDE.md](./SETUP_GUIDE.md)**
2. Review **API Documentation**
3. Check browser console for errors
4. Verify environment configuration

---

## 🎓 Next Steps

After mastering this project:

1. **Add WebSockets** for real-time updates
2. **Implement Categories** for task organization
3. **Add Collaboration** features (team tasks)
4. **Create Analytics** dashboard
5. **Build Mobile App** with React Native
6. **Add Testing** with Jest and React Testing Library
7. **Implement Caching** strategies
8. **Setup CI/CD** pipeline

---

## 🙏 Acknowledgments

Built with modern web technologies to demonstrate:
- Full-stack application development
- Professional UI/UX design
- Secure authentication patterns
- RESTful API best practices
- Database design principles

---

**Happy task managing! 🚀**

Last updated: January 2024  
Version: 1.0.0
