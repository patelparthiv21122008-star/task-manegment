-- ==================== TaskFlow Database Schema ====================
-- PostgreSQL SQL Script
-- Run this in your PostgreSQL database to set up the TaskFlow schema

-- Drop existing tables (if any - be careful!)
-- DROP TABLE IF EXISTS tasks CASCADE;
-- DROP TABLE IF EXISTS users CASCADE;

-- ==================== USERS TABLE ====================
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Constraints
  CONSTRAINT email_valid CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$'),
  CONSTRAINT name_not_empty CHECK (LENGTH(TRIM(name)) > 0)
);

-- Create index for email lookups (login)
CREATE INDEX idx_users_email ON users(email);

-- Create index for faster joins
CREATE INDEX idx_users_id ON users(id);

-- ==================== TASKS TABLE ====================
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT DEFAULT '',
  priority VARCHAR(50) DEFAULT 'medium' NOT NULL,
  status VARCHAR(50) DEFAULT 'todo' NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Constraints
  CONSTRAINT valid_priority CHECK (priority IN ('low', 'medium', 'high')),
  CONSTRAINT valid_status CHECK (status IN ('todo', 'in-progress', 'done')),
  CONSTRAINT title_not_empty CHECK (LENGTH(TRIM(title)) > 0)
);

-- Create indexes for common queries
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_tasks_created_at ON tasks(created_at DESC);
CREATE INDEX idx_tasks_user_status ON tasks(user_id, status);
CREATE INDEX idx_tasks_user_priority ON tasks(user_id, priority);

-- ==================== SAMPLE DATA (Optional) ====================
-- Uncomment to insert sample users and tasks for testing

-- -- Create sample user (password: "password123")
-- INSERT INTO users (email, name, password, created_at, updated_at) VALUES
-- ('demo@example.com', 'Demo User', '$2b$10$N9qo8uLOickgx2ZMRZoM.eDwCvxrHhs5Z.ItzcWssWE2xZWKW46Gy', NOW(), NOW());

-- -- Get user ID for sample tasks (usually 1 if first user)
-- -- INSERT INTO tasks (user_id, title, description, priority, status, created_at, updated_at) VALUES
-- -- (1, 'Sample Task 1', 'This is a sample task for testing', 'high', 'todo', NOW(), NOW()),
-- -- (1, 'Sample Task 2', 'Another task to try out', 'medium', 'in-progress', NOW(), NOW()),
-- -- (1, 'Sample Task 3', 'A completed task', 'low', 'done', NOW() - INTERVAL '1 day', NOW() - INTERVAL '1 day');

-- ==================== HELPFUL QUERIES ====================

-- View all users
-- SELECT * FROM users;

-- View all tasks for a specific user
-- SELECT * FROM tasks WHERE user_id = 1 ORDER BY created_at DESC;

-- Count tasks by status
-- SELECT status, COUNT(*) FROM tasks WHERE user_id = 1 GROUP BY status;

-- Count tasks by priority
-- SELECT priority, COUNT(*) FROM tasks WHERE user_id = 1 GROUP BY priority;

-- Delete all data (careful!)
-- DELETE FROM tasks;
-- DELETE FROM users;

-- Reset auto-increment counters
-- ALTER SEQUENCE users_id_seq RESTART WITH 1;
-- ALTER SEQUENCE tasks_id_seq RESTART WITH 1;

-- ==================== PERFORMANCE TIPS ====================
-- These indexes are optimized for:
-- 1. User authentication: idx_users_email (login lookup)
-- 2. Task retrieval: idx_tasks_user_id (get all user tasks)
-- 3. Filtering: idx_tasks_status, idx_tasks_priority
-- 4. Sorting: idx_tasks_created_at
-- 5. Combined queries: idx_tasks_user_status, idx_tasks_user_priority

-- ==================== BACKUP & RESTORE ====================
-- Backup database
-- pg_dump taskflow_db > taskflow_backup.sql

-- Restore database
-- psql taskflow_db < taskflow_backup.sql

-- ==================== END OF SCHEMA ====================
